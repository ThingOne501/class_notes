This directory contains the vector based version of the Phone Directory application.  The following files are included

Makefile		Makefile for g++

makefile.mak		Makefile for Visual Studio .NET

PD_Application.cpp	The Phone Directory application main program, modified
			to use the Vector_Based_PD class

phone.dat		A test file with phone directory data

README.txt		This file

Vector_Based_PD.cpp	Implementation of Vector_Based_PD

Vector_Based_PD.h	Definition of Vector_Based_PD
