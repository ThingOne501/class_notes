#ifndef INSERTIONSORT4_H_
#define INSERTIONSORT4_H_
#ifdef TRACE
#include "KW_Display.h"
#endif

#include <algorithm>

namespace KW {
} // End namespace KW

#endif
