#ifndef INSERTIONSORT3_H_
#define INSERTIONSORT3_H_

#include <algorithm>

namespace KW {


} // End namespace KW

#endif
