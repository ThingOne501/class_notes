/** Program to illustrate a division by zero error */
#include <iostream>

int main() {
  
  int sum = 0;
  int count = 0;
  double average;
average = sum / count;
  std::cout << "average is " << average << "\n";
}
