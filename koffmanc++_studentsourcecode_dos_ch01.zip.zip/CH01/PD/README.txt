This directory contains the following files:

Array_Based_PD.cpp	Implementation of the Array_Based_PD class (Listing 1.10)
Array_Based_PD.h	Definition of the Array_Based_PD class (Listing 1.9)
Makefile		A Makefile for g++ under Windows (MinGw)
makefile.mak		A Makefile for Visual Studio .NET (use nmake -fmakefile.mak)
PD_Application.cpp	The Phone Directory application main program (Listing 1.11)
phone.dat		A sample Phone Directory data file
README.txt		This file

