The following files are contained in this directory:

Clock.cpp		Implementation of the Clock class (Listing 1.2)
Clock.h			Definition of the Clock class (Listing 1.1)
Company.cpp		Implementation of the Company class (Listing 1.8)
Company.h		Definition of the Company class (Listing 1.7)
Makefile		A Makefile for g++ under Windows (MinGw)
makefile.mak		A makefile for Visual Studion .NET (use nmake -fmakefile.mak)
PD			The directory for the PhoneDirectory. (See its README.txt file)
Person.cpp		The implementation of the Person class (Listing 1.5)
Person.h		The definition of the Person class (Listing 1.4)
README.txt		This file
Test_Clock.cpp		Program to test the Clock class (Listing 1.3)
Test_Clockx.cpp		More detailed test of Clock class (not in text)
Test_Company.cpp	Test for the Company class (Section 1.3)
Test_Person.cpp		Test for the Person class (Listing 1.6)

