#include "Vegetable.h"

const double Vegetable::VEG_PROTEIN_CAL = 0.35;
const double Vegetable::VEG_FAT_CAL = 0.15;
const double Vegetable::VEG_CARBO_CAL = 0.50;
