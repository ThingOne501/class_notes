#ifndef VEGETABLE_H_
#define VEGETABLE_H_
#include <string>

#include "Food.h"

class Vegetable : public Food {
};

#endif
