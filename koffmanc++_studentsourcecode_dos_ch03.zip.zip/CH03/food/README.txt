This directory contains the following files

Food.h			Definition of the Food class
Makefile		Makefile for g++
makefile.mak		Makefile for Visual Studio .NET
README.txt		This file
test_Food.cpp		Test Program for food class
Vegetable.cpp		Implementation of the Vegetable class
Vegetable.h		Definition of the Vegetable class
