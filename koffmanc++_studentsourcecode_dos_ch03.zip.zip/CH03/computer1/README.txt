The following files are in this directory

Computer.cpp  The implementation of the Compuer class

Computer.h    The initial definition of Computer class as shown in listing 3.2

EX3P1P1.cpp   The soution to programming exercise 1, section 3.1

Lap_Top.h     The initial definition of the Lap_Top class as shown in listing 3.3

Makefile      A Makefile for g++
makefile.mak  A makefile for Visual Studio .NET

README.txt    This file

test_Computer.cpp  Program to demonstrate the computer class as shown in section 3.2
