The following files in this directory

Computer.cpp  Implementation of Computer class

Computer.h    Final version of Computer class including

Lap_Top.cpp   Implememntation of Lap_Top class

Lap_Top.h     Final version of Lap_Top class

Makefile      Makefile for g++

makefile.mak  Makefile for Visual Studio.NET

README.txt    This file

test_Computer2.cpp Test program to demonstrate ploymorphism in an array as shown in self-check exercise 3.2.2 

test_Computer.cpp  Test program of computer class containing code shown in various parts of the chapter.

