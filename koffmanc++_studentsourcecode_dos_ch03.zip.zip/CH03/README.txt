This directory contains the following sub-directories

Address:		The Address class and associated files.

airplanes:		The Airplanes class

ComputeAreaAndPerim:	The shapes case study

computer1:		Initial version of the Computer class

computer2:		Final version of the Computer class

food:			The food example

README.txt		This file

StudentWorker1:		Initial version of Student_Worker

StudentWorker2:		Revised version of Student_Worker

