This is the second version of the Student_Worker class to demonstrate
multiple inheritance.  This version compiles but does not factor out
the common Person information.  The factoring of the Person information
is in Appendix A

Address.h		Definition of the Address class
Employee.cpp		Implementation of the Employee class
Employee.h		Definition of the Employee class
German_Address.cpp	Implementation of the German_Address class
Makefile		Makefile for g++
makefile.mak		Makefile for Visual Studio .NET
README.txt		This file
Student.cpp		Implementation of Student
Student.h		Definition of Student
Student_Worker.cpp	Implementation of Student_Worker
Student_Worker.h	Definition of Student_Worker
Test_Address.cpp	Test of Address
Test_Employee.cpp	Test of Employee
Test_Student.cpp	Test of Student
Test_Student_Worker.cpp	Test of Student_Worker
US_Address.cpp		Implementation of US_Address

