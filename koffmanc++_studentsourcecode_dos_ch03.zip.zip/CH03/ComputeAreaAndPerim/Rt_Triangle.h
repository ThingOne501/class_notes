#ifndef RTTRIANGLE_H_
#define RTTRIANGLE_H_

#include "Shape.h"

/** Definition file for the class Rectangle */

class Rt_Triangle : public Shape
{

};

#endif
