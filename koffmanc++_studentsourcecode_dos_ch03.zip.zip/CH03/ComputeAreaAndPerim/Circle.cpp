/** Implementation of circle class */

