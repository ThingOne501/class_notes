/** Implementation of Parallelogram class. */
