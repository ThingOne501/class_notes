#ifndef CIRCLE_H_
#define CIRCLE_H_

#include "Shape.h"

/** Definition file for the class Rectangle */

class Circle : public Shape {

};

#endif
