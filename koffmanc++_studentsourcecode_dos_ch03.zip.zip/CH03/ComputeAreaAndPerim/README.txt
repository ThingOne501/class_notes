This directory contains the following files

Circle.cpp		    Implementation of the Circle class

Circle.h		    Definition of the Circle class

ComputeAreaAndPerim.cpp	    The main program

Makefile		    Makefile for g++

makefile.mak		    Makefile for Visual Studio .NET

Parallelogram.cpp	    Implementation of the Parallelogram class 
			    (exercise)

Parallelogram.h		    Definition of the Parallelogram class (exercise

README.txt		    This file

Rectangle.cpp		    Implementation of the Rectangle class

Rectangle.h		    Definition of the Rectangle class

Rt_Triangle.cpp		    Implementation of the Right Triangle class

Rt_Triangle.h		    Definition of the Right Triangle class

Shape.h			    Definition of the Shape class
