/** Implementation of right triangle class */

