#ifndef PARALLELOGRAM_H_
#define PARALLELOGRAM_H_

#include "Rectangle.h"

/** Definition file for the class Parallelogram. */
class Parallelogram : public Rectangle
{
};

#endif
