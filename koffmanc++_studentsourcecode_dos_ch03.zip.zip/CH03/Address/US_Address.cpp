/** Implementation file for the class US_Address */
