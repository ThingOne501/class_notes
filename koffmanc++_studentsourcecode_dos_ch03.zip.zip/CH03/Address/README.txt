This directory contains the following files:

Address.h		The definition of the Address class

German_Address.cpp	Implementation of the German_Adress class

Makefile		Makefile for g++ compiler

makefile.mak		Makefile for Visual Studio .NET compiler

README.txt		This file

Test_Address.cpp	Program to test the Address class

US_Address.cpp		Implementation of the US_Address class

