This directory contains the following files

Airplanes.cpp  Test program for the Airplanes class
Airplanes.h    Definition of the Airplanes class
Makefile       Makefile for g++
makefile.mak   Makefile for Visual Studio .NET
README.txt     This file
