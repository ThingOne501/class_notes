#include <iostream>
#include <string>
using std::cout;
using std::endl;
using std::string;

int main()
{
/*<snippet id="1" omit="false">*/
char c = 'A';
string s = "Hello";
int i = 12345;
float f = 123.45;
float b = 10e6;
float d = 1.234e-6;
cout << "c = " << c << endl;
cout << "s = " << s << endl;
cout << "i = " << i << endl;
cout << "f = " << f << endl;
cout << "b = " << b << endl;
cout << "d = " << d << endl;
/*</snippet>*/
}
