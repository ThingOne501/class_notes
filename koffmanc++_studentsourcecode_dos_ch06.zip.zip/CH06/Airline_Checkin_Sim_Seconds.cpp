/** Implementaiton of Airline Checkin Simulation
 *  This version uses a clock cycle of one second
 *   @author Koffman & Wolfgang
 */
